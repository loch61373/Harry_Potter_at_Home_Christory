package org.example;

public abstract class AbstractSpell {
}
