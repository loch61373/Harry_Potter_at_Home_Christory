package org.example;

public abstract class AbstractEnemy {
}


