package org.example;

public class House {
}
