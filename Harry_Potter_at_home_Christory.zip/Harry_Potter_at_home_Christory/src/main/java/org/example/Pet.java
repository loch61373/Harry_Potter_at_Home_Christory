package org.example;

public enum Pet {
    OWL,
    RAT,
    CAT,
    TOAD
}