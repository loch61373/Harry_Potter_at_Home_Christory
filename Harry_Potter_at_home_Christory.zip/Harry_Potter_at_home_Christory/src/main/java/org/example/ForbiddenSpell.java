package org.example;

public class ForbiddenSpell {
}
