package org.example;

public enum Core {
    UNICORN_HAIR,
    DRAGON_HEARTSTRING,
    PHOENIX_FEATHER
}

