package org.example;

public class Spell {
}
