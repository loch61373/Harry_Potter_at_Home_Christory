package org.example;

public class Wizard {
}
