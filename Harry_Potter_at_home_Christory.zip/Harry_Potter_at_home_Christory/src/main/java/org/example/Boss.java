package org.example;

public class Boss {
}
